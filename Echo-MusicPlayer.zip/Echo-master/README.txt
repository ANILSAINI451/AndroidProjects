This is a music player app, called Echo, created using android studio.
This app was created from scratch, by building different usesr interfaces and adding functionalities to them.

This was done as a part of a 6 weeks online training course, on App Development using Android, from Internshala.
